tinyMCE.addI18n('zh.example',{
	desc : '这是示例按钮'
});
