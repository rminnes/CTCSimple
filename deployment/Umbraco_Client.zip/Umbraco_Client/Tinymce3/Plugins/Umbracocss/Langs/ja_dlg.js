tinyMCE.addI18n('ja.example_dlg',{
	title : 'これは見出しの例です'
});
