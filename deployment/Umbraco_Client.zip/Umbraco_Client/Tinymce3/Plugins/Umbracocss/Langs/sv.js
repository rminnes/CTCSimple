tinyMCE.addI18n('sv.example',{
	desc : 'Detta är bara en mallknapp'
});
