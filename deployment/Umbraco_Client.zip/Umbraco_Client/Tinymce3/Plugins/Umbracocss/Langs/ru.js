tinyMCE.addI18n('ru.example',{
	desc : 'Это просто образец кнопки'
});
