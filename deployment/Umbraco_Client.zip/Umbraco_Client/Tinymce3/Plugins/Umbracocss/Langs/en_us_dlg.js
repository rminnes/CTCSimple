tinyMCE.addI18n('en_us.example_dlg',{
	title : 'This is just a example title'
});
