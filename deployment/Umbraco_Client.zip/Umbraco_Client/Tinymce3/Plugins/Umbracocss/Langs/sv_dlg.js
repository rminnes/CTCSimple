tinyMCE.addI18n('sv.example_dlg',{
	title : 'Detta är bara ett exempel på en titel'
});
