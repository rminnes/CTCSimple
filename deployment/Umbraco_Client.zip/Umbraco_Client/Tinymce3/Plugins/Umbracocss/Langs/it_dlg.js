tinyMCE.addI18n('it.example_dlg',{	
title : 'Esempio di titolo'
});
