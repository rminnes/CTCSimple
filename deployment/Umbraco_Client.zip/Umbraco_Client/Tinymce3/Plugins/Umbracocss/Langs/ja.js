tinyMCE.addI18n('ja.example',{
  desc : 'これはテンプレートボタンです'
});
