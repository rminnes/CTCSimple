tinyMCE.addI18n('it.example',{
desc : 'Esempio di pulsante'
});
