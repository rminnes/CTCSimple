tinyMCE.addI18n('en_us.example',{
	desc : 'This is just a template button'
});
