tinyMCE.addI18n('zh.example_dlg',{
	title : '这是示例标题'
});
