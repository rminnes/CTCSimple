tinyMCE.addI18n('ru.umbracomacro',{
    desc : 'Вставить макрос'
});
