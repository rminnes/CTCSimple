﻿tinyMCE.addI18n('he.umbracomacro',{
    desc : 'הוסף מאקרו'
});
