﻿tinyMCE.addI18n('ja.example_dlg',{
	title : 'これはタイトルの例です'
});
