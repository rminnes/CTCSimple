tinyMCE.addI18n('ja.umbracomacro',{
    desc : 'マクロの挿入'
});
