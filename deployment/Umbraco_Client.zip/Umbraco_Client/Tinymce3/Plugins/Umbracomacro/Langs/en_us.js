tinyMCE.addI18n('en_us.umbracomacro',{
    desc : 'Insert macro'
});
