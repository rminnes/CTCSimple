tinyMCE.addI18n('sv.umbracomacro',{
    desc : 'Infoga makro'
});
