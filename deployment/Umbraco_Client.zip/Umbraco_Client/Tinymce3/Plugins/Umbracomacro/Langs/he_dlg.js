tinyMCE.addI18n('he.example_dlg',{
	title : 'This is just a example title'
});
