tinyMCE.addI18n('zh.umbracomacro',{
    desc : '插入宏'
});
