tinyMCE.addI18n('sv.example_dlg',{
	title : 'Detta är bar ett exempel på en titel'
});
