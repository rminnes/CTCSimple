tinyMCE.addI18n('da.umbracoembed', {
    desc: 'Inds\u00E6t ekstern mediefil'
});
