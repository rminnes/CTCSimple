tinyMCE.addI18n('en_us.embed_dlg', {
    title: 'Embed third party media',
    general: 'General',
    url: 'Url:',
    size: 'Size:',
    constrain_proportions: 'Constrain',
    preview: 'Preview',
    source: 'Source'

});
