tinyMCE.addI18n('ru.embed_dlg', {
    title: 'Вставить внеший элемент медиа',
    general: 'Общее',
    url: 'Ссылка:',
    size: 'Размер:',
    constrain_proportions: 'Сохранять пропорции',
    preview: 'Просмотр',
    source: 'Источник'

});