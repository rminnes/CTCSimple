tinyMCE.addI18n('zh.embed_dlg', {
    title: '嵌入第三方媒体',
    general: '普通',
    url: '链接：',
    size: '尺寸：',
    constrain_proportions: '约束比例',
    preview: '预览',
    source: '源'
});
