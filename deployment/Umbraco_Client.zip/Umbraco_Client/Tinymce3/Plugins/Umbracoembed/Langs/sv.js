tinyMCE.addI18n('sv.embed_dlg', {
    title: 'Bädda in tredjeparts media',
    general: 'Generell',
    url: 'Url:',
    size: 'Storlek:',
    constrain_proportions: 'Bibehåll proportioner',
    preview: 'Förhandsgranska',
    source: 'Källa'

});