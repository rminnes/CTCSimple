tinyMCE.addI18n('en.umbracoembed', {
    desc: 'Embed third party media'
});