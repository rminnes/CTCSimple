tinyMCE.addI18n('de.embed_dlg', {
    title: 'Medien von Drittanbietern einbetten',
    general: 'Allgemein',
    url: 'Url:',
    size: 'Abmessungen:',
    constrain_proportions: 'Proportionen beibehalten',
    preview: 'Vorschau',
    source: 'Quellcode'

});
