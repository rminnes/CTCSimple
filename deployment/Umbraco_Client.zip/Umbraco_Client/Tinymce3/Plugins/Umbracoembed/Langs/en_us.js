tinyMCE.addI18n('en_us.umbracoembed', {
    desc: 'Embed third party media'
});