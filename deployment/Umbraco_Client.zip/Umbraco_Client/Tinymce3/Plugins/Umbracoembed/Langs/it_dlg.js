tinyMCE.addI18n('it.embed_dlg', {    
title: 'Integra media di terze parti',    
general: 'Generale',    
url: 'Url:',    
size: 'Dimensione:',    
constrain_proportions: 'Vincolo',    
preview: 'Anteprima',    
source: 'Sorgente'
});
