tinyMCE.addI18n('ja.embed_dlg', {
    title: サードパーティメディアの埋め込み',
    general: '一般',
    url: 'Url:',
    size: 'サイズ:',
    constrain_proportions: '制約',
    preview: 'プレビュー',
    source: 'ソース'

});
