tinyMCE.addI18n('da.embed_dlg', {
    title: 'Inds\u00E6t ekstern mediefil',
    general: 'Generelt',
    url: 'Url:',
    size: 'Dimensioner:',
    constrain_proportions: 'Bevar proportioner',
    preview: 'Vis',
    source: 'Vis kilde'
});
